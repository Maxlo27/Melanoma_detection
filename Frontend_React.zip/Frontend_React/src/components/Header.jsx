// Header.jsx

import React from 'react';

import styles from "./Header.module.css"
import Nav from './Nav';

const Header = () => {
    return <header>
        <Nav />
        


    </header>


};

export default Header;

